# Bracket Validator Lab 5

Пакет для перевірки балансу дужок у рядках.